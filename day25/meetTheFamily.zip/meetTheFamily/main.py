#!/usr/bin/env
# importing object
from family_tree_node import FamilyTree
import constants


# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.
def build_family_tree():
    # init family tree
    root = FamilyTree("Arthur", "Male")
    dad_wife = FamilyTree("Margret", "Female")
    root.married(dad_wife)
    dad_wife.married(root)
    # ------------------------------------
    bill = FamilyTree("Bill", "Male")
    root.add_child(bill)
    flora = FamilyTree("Flora", "Female")
    bill.married(flora)
    flora.married(bill)

    victorie = FamilyTree("Victorie", "Female")
    bill.add_child(victorie)
    ted = FamilyTree("Ted", "Male")
    victorie.married(ted)
    ted.married(victorie)

    remus = FamilyTree("Remus", "Male")
    victorie.add_child(remus)

    dominique = FamilyTree("Dominique", "Female")
    bill.add_child(dominique)

    louis = FamilyTree("Louis", "Male")
    bill.add_child(louis)

    # ------------------------------------
    charlie = FamilyTree("Charlie", "Male")
    root.add_child(charlie)
    # ------------------------------------
    percy = FamilyTree("Percy", "Male")
    root.add_child(percy)
    audrey = FamilyTree("Audrey", "Female")
    percy.married(audrey)
    audrey.married(percy)

    molly = FamilyTree("Molly", "Female")
    percy.add_child(molly)

    lucy = FamilyTree("Lucy", "Female")
    percy.add_child(lucy)
    # ------------------------------------
    ronald = FamilyTree("Ronald", "Male")
    root.add_child(ronald)
    helen = FamilyTree("Helen", "Female")
    ronald.married(helen)
    helen.married(ronald)

    rose = FamilyTree("Rose", "Female")
    ronald.add_child(rose)
    malfoy = FamilyTree("Helen", "Male")
    rose.married(malfoy)
    malfoy.married(rose)

    draco = FamilyTree("Draco", "Male")
    rose.add_child(draco)

    aster = FamilyTree("Aster", "Female")
    rose.add_child(aster)

    hugo = FamilyTree("hugo", "Male")
    ronald.add_child(hugo)
    # ------------------------------------
    ginerva = FamilyTree("Ginerva", "Female")
    root.add_child(ginerva)
    harry = FamilyTree("Harry", "Male")
    ginerva.married(harry)
    harry.married(ginerva)

    james = FamilyTree("James", "Male")
    ginerva.add_child(james)
    darcy = FamilyTree("Darcy", "Female")
    james.married(darcy)
    darcy.married(james)

    william = FamilyTree("William", "Male")
    james.add_child(william)

    albus = FamilyTree("Albus", "Male")
    ginerva.add_child(albus)
    alice = FamilyTree("Alice", "Female")
    albus.married(alice)
    alice.married(albus)

    ron = FamilyTree("Ron", "Male")
    albus.add_child(ron)

    ginny = FamilyTree("Ginny", "Female")
    albus.add_child(ginny)

    lily = FamilyTree("Lily", "Female")
    ginerva.add_child(lily)
    # ------------------------------------

    # importing from file.txt
    command_from_txt = []
    with open(constants.FILENAME) as f:
        for line in f:
            x = line.split()
            command_from_txt.append(x)

    for command in command_from_txt:
        # if the command get_relationship
        if command[0] == constants.GET_RELATIONSHIP:
            print("")
            # if the command looking for FATHERS BROTHER
            if command[2] == constants.PATERNAL_UNCLE:
                person = root.findPerson(command[1])
                if person:
                    parents = person.get_parent()
                    if parents.gender == constants.MALE:
                        grand_parents = parents.get_parent()
                        if grand_parents != None:
                            for child in grand_parents.children:
                                if child.gender == constants.MALE and child.data != person.parent.data:
                                    print(child.data, end=' ')
                    else:
                        print("NONE")
                else:
                    print("PERSON_NOT_FOUND")
            elif command[2] == constants.PATERNAL_AUNT:
                # if the command looking for FATHERS SISTERS
                print("")
                person = root.findPerson(command[1])
                if person:
                    parents = person.get_parent()
                    if parents.gender == constants.MALE:
                        grand_parents = parents.get_parent()
                        if grand_parents != None:
                            for child in grand_parents.children:
                                if child.gender == constants.FEMALE and child.data != person.parent.data:
                                    print(child.data, end=' ')
                    else:
                        print("NONE")
                else:
                    print("PERSON_NOT_FOUND")
            elif command[2] == constants.MATERNAL_UNCLE:
                # if the command looking for MOTHERS BROTHERS
                print("")
                person = root.findPerson(command[1])
                if person:
                    parents = person.get_parent()
                    if parents.gender == constants.FEMALE:
                        grand_parents = parents.get_parent()
                        if grand_parents != None:
                            for child in grand_parents.children:
                                if child.gender == constants.MALE and child.data != person.parent.data:
                                    print(child.data, end=' ')
                    else:
                        print("NONE")
                else:
                    print("PERSON_NOT_FOUND")
            elif command[2] == constants.MATERNAL_AUNT:
                # if the command looking for MOTHERS SISTERS
                print("")
                person = root.findPerson(command[1])
                if person:
                    parents = person.get_parent()
                    if parents.gender == constants.FEMALE:
                        grand_parents = parents.get_parent()
                        if grand_parents != None:
                            for child in grand_parents.children:
                                if child.gender == constants.FEMALE and child.data != person.parent.data:
                                    print(child.data, end=' ')
                    else:
                        print("NONE")
                else:
                    print("PERSON_NOT_FOUND")
            elif command[2] == constants.SISTER_IN_LAW:
                # if the command looking for SISTERS IN LAW
                print("")
                person = root.findPerson(command[1])
                if person:
                    parents = person.get_parent()
                    if parents:
                        for child in parents.children:
                            if child.partner and child.gender == constants.MALE and child.data != command[1]:
                                sister_in_law = child.partner
                                print(sister_in_law.data, end=' ')
                            else:
                                print("NONE")
                    else:
                        parents = person.partner.get_parent()
                        if parents:
                            for child in parents.children:
                                if child.gender == constants.FEMALE and child.data != person.partner.data:
                                    print(child.data, end=' ')
                                else:
                                    print("NONE")
                else:
                    print("PERSON_NOT_FOUND")
            elif command[2] == constants.BROTHER_IN_LAW:
                # if the command looking for BROTHERS IN LAW
                print("")
                person = root.findPerson(command[1])
                if person:
                    parents = person.get_parent()
                    if parents:
                        for child in parents.children:
                            if child.partner and child.gender == constants.FEMALE and child.data != command[1]:
                                brother_in_law = child.partner
                                print(brother_in_law.data, end=' ')
                            else:
                                print("NONE")
                    else:
                        parents = person.partner.get_parent()
                        if parents:
                            for child in parents.children:
                                if child.gender == constants.MALE and child.data != person.partner.data:
                                    print(child.data, end=' ')
                                else:
                                    print("NONE")
                else:
                    print("PERSON_NOT_FOUND")
            elif command[2] == constants.SIBLINGS:
                # if the command get relation siblings
                person = root.findPerson(command[1])
                if person:
                    parents = person.get_parent()
                    for child in parents.children:
                        if child:
                            if child.data != person.data:
                                print(child.data, end=' ')
                        else:
                            print("NONE")
                else:
                    print("PERSON_NOT_FOUND")

        elif command[0] == constants.ADD_CHILD:
            person = root.findPerson(command[1])
            child = FamilyTree(command[2], command[3])
            if person:
                if person.parent:
                    print("CHILD_ADDED")
                    person.add_child(child)
                else:
                    print("CHILD_ADDED")
                    person.partner.add_child(child)
            else:
                print("CHILD_ADDIDITION_FAILED")

    print("")


    print("-------------------")
    #PRINTING THE FAMILY TREE FOR TESTING PURPOSE AND EASYER EXAMINATION
    root.print_tree()

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    root = build_family_tree()
    pass

root = FamilyTree("Dad", "Male")
dad_wife = FamilyTree("Mom", "Female")
root.married(dad_wife)

firstchild = FamilyTree("FirstChild", "Male")

firstGrandChild = FamilyTree("firstGrandChild", "Male")
firstchild.add_child(firstGrandChild)
sarah = FamilyTree("Sarah", "Female")
firstGrandChild.married(sarah)

firstchild.add_child(FamilyTree("secondGrandChild", "Male"))

firstchild.add_child(FamilyTree("thirdGrandChild", "Male"))

secondchild = FamilyTree("SecondChild", "Male")
mia = FamilyTree("Mia", "Female")
secondchild.married(mia)

secondchild.add_child(FamilyTree("firstGrandChilde", "Male"))
secondchild.add_child(FamilyTree("secondGrandChilde", "Male"))
secondchild.add_child(FamilyTree("thirdGrandChilde", "Male"))

thirdchild = FamilyTree("ThirdChild", "Male")
hanna = FamilyTree("Hanna", "Female")
thirdchild.married(hanna)
thirdchild.add_child(FamilyTree("firstGrandChildes", "Male"))
thirdchild.add_child(FamilyTree("secondGrandChildes", "Male"))
thirdchild.add_child(FamilyTree("thirdGrandChildes", "Male"))

root.add_child(firstchild)
root.add_child(secondchild)
root.add_child(thirdchild)

from family_tree_node import FamilyTree
FILENAME = "file.txt"
ADD_CHILD = 'ADD_CHILD'
GET_RELATIONSHIP = 'GET_RELATIONSHIP'
FEMALE = 'Female'
MALE = 'Male'
PATERNAL_UNCLE = 'Paternal-Uncle'
PATERNAL_AUNT = 'Paternal-Aunt'
MATERNAL_UNCLE = 'Maternal-Uncle'
MATERNAL_AUNT = 'Maternal-Aunt'
SISTER_IN_LAW = 'Sister-In-Law'
BROTHER_IN_LAW = 'Brother-In-Law'
SIBLINGS = 'Siblings'


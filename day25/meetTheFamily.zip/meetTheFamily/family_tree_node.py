class FamilyTree:
    # create object / person / kong
    def __init__(self, data, gender):
        self.parent = None
        self.children = []
        self.partner = None
        self.data = data
        self.gender = gender
        # self.gender = gender

    # add partner relation
    def married(self, data):
        self.partner = data

    # adding lvl attribute
    def get_level(self):
        level = 0
        p = self.parent
        while p:
            level += 1
            p = p.parent
        return level
    #######################################################################
    ###################################################################################
    ####################################################

    # create child relation
    def add_child(self, child):
        child.parent = self
        self.children.append(child)

    # print tree
    def print_tree(self):
        spaces = ' ' * self.get_level() * 3
        prefix = spaces + "|__" if self.parent else ""
        partner_prefix = spaces + "|__"
        print(prefix + self.data)
        if self.partner:
                spaces = ' ' * self.partner.get_level() * 3
                partner_prefix = spaces + "|__"
                print(prefix + self.partner.data)
        if self.children:
            for child in self.children:
                child.print_tree()

    # get parent relation
    def get_parent(self):
        return self.parent

    # get children relation
    def get_child(self):
        return self.children

    # find the node person in the tree
    def findPerson(self, PersonName):
        """
        Returns pointer of the node corresponding to person Name
        """
        if self.data == PersonName:
            return self
        else:
            if self.partner:
                    if self.partner.data == PersonName:
                        return self.partner
                    else:
                        if self.children:
                            for child in self.children:
                                result = child.findPerson(PersonName)
                                if result is not None:
                                    return result
                                elif child.data == PersonName:
                                    return child

                        else:
                            return 0








